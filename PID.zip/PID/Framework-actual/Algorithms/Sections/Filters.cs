﻿namespace Algorithms.Sections
{
    public class Filters
    {
    }
}