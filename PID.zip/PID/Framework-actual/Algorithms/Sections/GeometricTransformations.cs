﻿namespace Algorithms.Sections
{
    public class GeometricTransformations
    {
    }
}