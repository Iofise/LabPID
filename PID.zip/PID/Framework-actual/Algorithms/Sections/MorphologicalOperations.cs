﻿namespace Algorithms.Sections
{
    public class MorphologicalOperations
    {
    }
}