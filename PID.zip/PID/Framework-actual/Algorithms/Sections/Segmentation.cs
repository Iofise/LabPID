﻿namespace Algorithms.Sections
{
    public class Segmentation
    {
    }
}