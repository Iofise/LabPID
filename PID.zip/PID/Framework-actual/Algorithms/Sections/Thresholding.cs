﻿namespace Algorithms.Sections
{
    public class Thresholding
    {

    }
}