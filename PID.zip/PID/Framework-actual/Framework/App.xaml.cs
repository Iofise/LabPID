﻿using System.Windows;

namespace Framework
{
    public partial class App : Application
    {
    }
}
