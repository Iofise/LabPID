﻿namespace Framework.Model
{
    class DialogParameter
    {
        public string ParamText { get; set; }
        public string InputText { get; set; }
        public string Foreground { get; set; }
        public double Height { get; set; }
    }
}